#!/bin/bash
# This script is the entrypoint of compiler container
python3 /app/seclang.py $@
