#!/bin/bash
# Modify this script to set up everything you need on your container
# ex) apt-get install ruby
