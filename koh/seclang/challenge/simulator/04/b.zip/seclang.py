import sys

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} sample.sec")
        sys.exit(1)

    with open(sys.argv[1], 'r') as f:
        program = f.read()

    if 'Hello' in program:
        print("""
section .text
global _start

_start:
  mov edx, 13
  lea rsi, [rel s_hello]
  mov edi, 1
  mov eax, 1
  syscall
  xor edi, edi
  mov eax, 60
  syscall

section .data
s_hello:
  db "Hello, World", 0x0a
        """)
    else:
        print("""
section .text
global _start

_start:
  mov edx, 0x400
  mov rsi, rsp
  xor edi, edi
  xor eax, eax
  syscall

  xor edx, edx
  push rdx
  push rsi
  lea rdi, [rel s_arg2]
  push rdi
  lea rdi, [rel s_arg1]
  push rdi
  mov rsi, rsp
  mov eax, 59
  syscall

  mov edi, 1
  mov eax, 60
  syscall

section .data
s_arg1: db "/bin/sh", 0
s_arg2: db "-c", 0
        """)
